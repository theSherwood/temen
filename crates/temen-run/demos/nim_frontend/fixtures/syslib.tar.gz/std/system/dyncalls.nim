#
#
#            Nim's Runtime Library
#        (c) Copyright 2012 Andreas Rumpf
#
#    See the file "copying.txt", included in this
#    distribution, for details about the copyright.
#

# This file implements the ability to call native procs from libraries.
# It is not possible to do this in a platform independent way, unfortunately.
# However, the interface has been designed to take platform differences into
# account and been ported to all major platforms.

# {.push stack_trace: off.}

type
  LibHandle = pointer       # private type
  ProcAddr = pointer        # library loading and loading of procs:


const
  NilLibHandle: LibHandle = nil


# proc nimLoadLibrary(path: cstring): LibHandle {.exportc: "nimLoadLibrary".}
# proc nimGetProcAddr(lib: LibHandle, name: cstring): ProcAddr {.exportc: "nimGetProcAddr"}, nodecl.}


when defined(windows):
  # Bare kernel32 import (no `header: "<windows.h>"`): nimony emits the
  # prototype and the linker binds the symbol, keeping the `system` translation
  # unit header-free for the all-native target (see `system/panics`). `nodecl`
  # is dropped along with the header so a prototype is actually emitted.
  proc GetLastError(): int32 {.importc: "GetLastError", stdcall,
                               dynlib: "kernel32".}
  const ERROR_BAD_EXE_FORMAT = 193

proc nimLoadLibraryError(path: string) =
  # carefully written to avoid memory allocation:
  const prefix = "could not load: "
  writeErr(prefix)
  writeErr(path)
  when not defined(nimDebugDlOpen) and not defined(windows):
    writeErr("\n(compile with -d:nimDebugDlOpen for more information)")
  when defined(windows):
    const badExe = "\n(bad format; library may be wrong architecture)"
    let loadError = GetLastError()
    if loadError == ERROR_BAD_EXE_FORMAT:
      writeErr(badExe)
    when defined(guiapp):
      # Because console output is not shown in GUI apps, display the error as a
      # message box instead:
      var
        msg: array[1000, char]
        msgLeft = msg.len - 1 # leave (at least) one for nullchar
        msgIdx = 0
      copyMem(msg[msgIdx].addr, prefix.cstring, prefix.len)
      msgLeft -= prefix.len
      msgIdx += prefix.len
      let pathLen = min(path.len, msgLeft)
      copyMem(msg[msgIdx].addr, path.cstring, pathLen)
      msgLeft -= pathLen
      msgIdx += pathLen
      if loadError == ERROR_BAD_EXE_FORMAT and msgLeft >= badExe.len:
        copyMem(msg[msgIdx].addr, badExe.cstring, badExe.len)
      discard MessageBoxA(nil, msg[0].addr, nil, 0)
  writeErr("\n")
  die(1)

proc procAddrError(name: cstring) =
  # carefully written to avoid memory allocation:
  writeErr("could not import: ")
  writeErr(name)
  writeErr("\n")
  die(1)

# this code was inspired from Lua's source code:
# Lua - An Extensible Extension Language
# Tecgraf: Computer Graphics Technology Group, PUC-Rio, Brazil
# https://www.lua.org
# mailto:info@lua.org

when defined(posix):
  #
  # =========================================================================
  # This is an implementation based on the dlfcn interface.
  # The dlfcn interface is available in Linux, SunOS, Solaris, IRIX, FreeBSD,
  # NetBSD, AIX 4.2, HPUX 11, and probably most other Unix flavors, at least
  # as an emulation layer on top of native functions.
  # =========================================================================
  #

  # c stuff (values transcribed per OS; RTLD_NOW is 2 on both Linux and
  # Darwin, RTLD_GLOBAL differs — 0x100 vs 0x8):
  const RTLD_NOW = cint(2)
  when defined(globalSymbols):
    const RTLD_GLOBAL = (when defined(osx): cint(0x8) else: cint(0x100))

  proc dlclose(lib: LibHandle) {.importc: "dlclose".}
  proc dlopen(path: cstring, mode: cint): LibHandle {.importc: "dlopen".}
  proc dlsym(lib: LibHandle, name: cstring): ProcAddr {.importc: "dlsym".}

  proc dlerror(): cstring {.importc: "dlerror".}

  proc nimUnloadLibrary(lib: LibHandle) =
    dlclose(lib)

  proc nimLoadLibrary(path: cstring): LibHandle {.exportc: "nimLoadLibrary".} =
    let flags =
      when defined(globalSymbols): RTLD_NOW or RTLD_GLOBAL
      else: RTLD_NOW
    result = dlopen(path, flags)
    when defined(nimDebugDlOpen):
      let error = dlerror()
      if error != nil:
        writeErr(error)
        writeErr("\n")

  proc nimGetProcAddr(lib: LibHandle, name: cstring): ProcAddr {.exportc: "nimGetProcAddr"} =
    result = dlsym(lib, name)
    if result == nil: procAddrError(name)

elif defined(windows) or defined(dos):
  #
  # =======================================================================
  # Native Windows Implementation
  # =======================================================================

  when defined(cpp):
    type
      THINSTANCE {.importc: "HINSTANCE", header: "<windows.h>".} = object
        x: pointer
    proc getProcAddress(lib: THINSTANCE, name: cstring): ProcAddr {.
        importcpp: "(void*)GetProcAddress(@)", header: "<windows.h>", stdcall.}
  else:
    # TODO: use `importc: "HINSTANCE"` when available
    type
      THINSTANCE = pointer
  # kernel32 imports without `<windows.h>`, keeping the `system` unit
  # header-free (see `panics`). `dynlib` = static import library on every
  # backend — these are the runtime loader's own bootstrap, so a static
  # import-table entry is exactly what they need.
  proc getProcAddress(lib: THINSTANCE, name: cstring): ProcAddr {.
      importc: "GetProcAddress", stdcall, dynlib: "kernel32".}

  proc freeLibrary(lib: THINSTANCE) {.
      importc: "FreeLibrary", stdcall, dynlib: "kernel32".}
  proc winLoadLibrary(path: cstring): THINSTANCE {.
      importc: "LoadLibraryA", stdcall, dynlib: "kernel32".}

  proc nimUnloadLibrary(lib: LibHandle) =
    freeLibrary(cast[THINSTANCE](lib))

  proc nimLoadLibrary(path: cstring): LibHandle {.exportc: "nimLoadLibrary".} =
    result = cast[LibHandle](winLoadLibrary(path))

  proc nimGetProcAddr(lib: LibHandle, name: cstring): ProcAddr {.exportc: "nimGetProcAddr"} =
    result = getProcAddress(cast[THINSTANCE](lib), name)
    if result != nil: return
    const decoratedLength = 250
    var decorated: array[decoratedLength, char] = default(array[decoratedLength, char])
    decorated[0] = '_'
    var m: range[1 .. decoratedLength - 5] = 1
    while m < (decoratedLength - 5):
      if name[m - 1] == '\x00': break
      decorated[m] = name[m - 1]
      inc(m)
    decorated[m] = '@'
    let at = m
    for i in 0..50:
      # `@` then the decimal digits of `i * 4` (at most three) and a NUL
      var k = i * 4
      var last = at + 3
      if k div 100 == 0:
        if k div 10 == 0:
          last = at + 1
        else:
          last = at + 2
      decorated[last + 1] = '\x00'
      var d: range[2 .. decoratedLength - 2] = last
      while true:
        decorated[d] = chr(ord('0') + (k mod 10))   # k is always >= 0 here
        k = k div 10
        if k == 0 or d <= at + 1: break
        d = d - 1
      result = getProcAddress(cast[THINSTANCE](lib), cast[cstring](addr decorated))
      if result != nil: return
    procAddrError(name)

elif defined(genode):

  proc nimUnloadLibrary(lib: LibHandle) =
    raiseAssert("nimUnloadLibrary not implemented")

  proc nimLoadLibrary(path: cstring): LibHandle {.exportc: "nimLoadLibrary".} =
    raiseAssert("nimLoadLibrary not implemented")

  proc nimGetProcAddr(lib: LibHandle, name: cstring): ProcAddr {.exportc: "nimGetProcAddr"} =
    raiseAssert("nimGetProcAddr not implemented")

elif defined(nintendoswitch) or defined(freertos) or defined(zephyr) or defined(nuttx):
  proc nimUnloadLibrary(lib: LibHandle) =
    writeErr("nimUnLoadLibrary not implemented")
    writeErr("\n")
    die(1)

  proc nimLoadLibrary(path: cstring): LibHandle {.exportc: "nimLoadLibrary".} =
    writeErr("nimLoadLibrary not implemented")
    writeErr("\n")
    die(1)


  proc nimGetProcAddr(lib: LibHandle, name: cstring): ProcAddr {.exportc: "nimGetProcAddr"} =
    writeErr("nimGetProAddr not implemented")
    writeErr(name)
    writeErr("\n")
    die(1)

else:
  # Freestanding targets without dynamic loading (standalone, wasm32, …):
  # same loud-stub shape as the embedded arm above — the symbols exist so
  # generic code links, and any actual use aborts with a message.
  proc nimLoadLibrary(path: cstring): LibHandle {.exportc: "nimLoadLibrary".} =
    writeErr("nimLoadLibrary not implemented")
    writeErr("\n")
    die(1)

  proc nimGetProcAddr(lib: LibHandle, name: cstring): ProcAddr {.exportc: "nimGetProcAddr"} =
    writeErr("nimGetProcAddr not implemented")
    writeErr(name)
    writeErr("\n")
    die(1)

proc nimDynlibLoadStep(prev: LibHandle; cand: cstring): LibHandle {.exportc: "nimDynlibLoadStep".} =
  ## One step of a compile-time-expanded dynlib name pattern: keep the first
  ## candidate that loaded, otherwise try loading `cand`. The code generator
  ## expands a pattern such as `libX11.so(|.6)` into a left-nested chain of
  ## these calls, so the alternatives are tried in order at startup.
  if prev != nil: result = prev
  else: result = nimLoadLibrary(cand)

proc nimDynlibCheck(lib: LibHandle; path: cstring): LibHandle {.exportc: "nimDynlibCheck".} =
  ## Final check wrapped around the candidate chain: abort with a useful
  ## message if none of the candidate names could be loaded. `path` is the
  ## original (unexpanded) pattern, for diagnostics.
  if lib == nil:
    writeErr("could not load: ")
    writeErr(path)
    writeErr("\n")
    die(1)
  result = lib

# {.pop.}
